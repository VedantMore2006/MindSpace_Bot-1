"""
Model wrapper for backward compatibility.
Uses the main llm instance from llm.py.
"""

from llm import llm as main_llm

class AnthropicChatClient:
    """Wrapper for ChatAnthropic to maintain compatibility."""
    
    def __init__(self):
        self.llm = main_llm
    
    def invoke(self, messages):
        """Invoke the LLM with messages."""
        try:
            response = self.llm.invoke(messages)
            return response
        except Exception as e:
            print(f"Error in LLM invoke: {e}")
            raise

llm = AnthropicChatClient()