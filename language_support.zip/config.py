import os
from dotenv import load_dotenv

load_dotenv()

# API Keys
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")

# Model configurations
ANTHROPIC_MODEL = "claude-sonnet-4-6"

# Application settings
MAX_HISTORY_LENGTH = 50
MAX_CONTEXT_MESSAGES = 20
MEMORY_FILE_PATH = os.getenv("MEMORY_FILE_PATH", "conversation_memory.json")

# Safety Settings
CRISIS_DETECTION_ENABLED = os.getenv("CRISIS_DETECTION_ENABLED", "True").lower() == "true"
OFF_TOPIC_DETECTION_ENABLED = os.getenv("OFF_TOPIC_DETECTION_ENABLED", "True").lower() == "true"
PROMPT_INJECTION_DETECTION = os.getenv("PROMPT_INJECTION_DETECTION", "True").lower() == "true"
OFFENSIVE_CONTENT_FILTER = os.getenv("OFFENSIVE_CONTENT_FILTER", "True").lower() == "true"

# Session Settings
SESSION_TIMEOUT_HOURS = 24  # Sessions expire after 24 hours
MAX_SESSIONS_PER_USER = 5

# API Settings
API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", 8000))
API_RELOAD = os.getenv("API_RELOAD", "False").lower() == "true"