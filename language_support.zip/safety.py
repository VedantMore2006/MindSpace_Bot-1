"""
Safety detection module.
"""

from langchain_core.messages import HumanMessage
from llm import llm


def detect_self_harm_risk(text: str) -> bool:
    """
    Detect if a message indicates self-harm or suicidal thoughts.
    Returns True if HIGH_RISK, False if SAFE.
    """
    try:
        prompt = f"""
Classify the user's message as HIGH_RISK or SAFE.

HIGH_RISK includes messages expressing:
- wanting to die
- suicide thoughts
- self-harm thoughts
- not wanting to live
- wanting life to end
- wanting to disappear forever

Examples of HIGH_RISK:
- "I want to die"
- "I don't want to live anymore"
- "मुझे मर जाना है" (Hindi)
- "मला मरून जावंसं वाटतं" (Marathi)

Everything else is SAFE.

Message:
{text}
"""

        response = llm.invoke([HumanMessage(content=prompt)])
        result = response.content.strip()
        return result == "HIGH_RISK"

    except Exception as e:
        print(f"Error in safety detection: {e}")
        return True